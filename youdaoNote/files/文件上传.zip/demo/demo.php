<?php
	session_start();
?>
<html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8">
		<title>Demo</title>
	</head>
	<body>
		<?php
			if(isset($_SESSION['error'])){
				echo $_SESSION['error'];
			}
		?>
		<form action="./chuli.php" method="post" enctype="multipart/form-data">
			<!-- 可以设置一个隐藏域，限制文件上传的大小，但是并不安全，该行代码必须写在file的上面 -->
			<input type="hidden" name="MAX_FILE_SIZE" value="102400"/>
			<input type="file" name="ztzFile[]"/>
			<input type="file" name="ztzFile[]"/>
			<input type="file" name="ztzFile[]"/>
			<br/>
			<input type="submit" name='submit'/>
		</form>
	</body>
</html>
