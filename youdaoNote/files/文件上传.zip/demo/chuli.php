<?php
session_start();
if(isset($_POST['submit'])){
	$count=count($_FILES['ztzFile']['type']);
	for($i=0;$i<$count;$i++){
			if($_FILES['ztzFile']['error'][$i]>0){
				//die(" $i 您上传的文件发生了错误，请<a href='./demo.php'>返回</a>");
				//可以将发生的错误信息保留起来，然后在页面中返回给用户
				$_SESSION['error']="...文件出错";
				continue;
			}
			$arr=getimagesize($_FILES['ztzFile']['tmp_name'][$i]);
			$name=date('YmdHis').'_'.mt_rand(0,1000).mt_rand(0,1000);
			move_uploaded_file($_FILES['ztzFile']['tmp_name'][$i],"./img/{$name}.jpg");
		}
}
header('location:./demo.php');
?>
